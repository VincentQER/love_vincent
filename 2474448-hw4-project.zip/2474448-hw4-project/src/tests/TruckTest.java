package tests;

import model.*;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for class Human.
 *
 * @author Vincent Xu
 * @version Fall 2024
 */
public class TruckTest {

    /**
     * The number of times to repeat a test to have a high probability that all
     * random possibilities have been explored.
     */
    private static final int TRIES_FOR_RANDOMNESS = 50;

    /**
     * Test the Truck constructor.
     */
    @Test
    public void testTruckConstructor() {
        final Truck truck = new Truck(10, 11, Direction.NORTH);

        assertEquals(10, truck.getX(), "Truck x coordinate not initialized correctly!");
        assertEquals(11, truck.getY(), "Truck y coordinate not initialized correctly!");
        assertEquals(Direction.NORTH, truck.getDirection(), "Truck direction not initialized correctly!");
        assertEquals(0, truck.getDeathTime(), "Truck death time should always be zero!");
        assertTrue(truck.isAlive(), "Truck should initially be alive!");
    }

    /**
     * Test method for {@link Truck#canPass(Terrain, Light)}.
     */
    @Test
    public void testCanPass() {
        final Truck truck = new Truck(0, 0, Direction.NORTH);

        for (final Terrain terrain : Terrain.values()) {
            for (final Light light : Light.values()) {
                if (terrain == Terrain.STREET || terrain == Terrain.LIGHT) {
                    assertTrue(truck.canPass(terrain, light),
                            "Truck should be able to pass on " + terrain + " with light " + light);
                } else if (terrain == Terrain.CROSSWALK) {
                    if (light == Light.RED) {
                        assertFalse(truck.canPass(terrain, light),
                                "Truck should NOT pass CROSSWALK with red light.");
                    } else {
                        assertTrue(truck.canPass(terrain, light),
                                "Truck should pass CROSSWALK with non-red light.");
                    }
                } else {
                    assertFalse(truck.canPass(terrain, light),
                            "Truck should NOT pass on " + terrain + " with light " + light);
                }
            }
        }
    }

    /**
     * Test method for {@link Truck#chooseDirection(java.util.Map)}.
     */
    @Test
    public void testChooseDirectionWithValidOptions() {
        // The Truck only mak
        final Map<Direction, Terrain> neighbors = new HashMap<>();
        neighbors.put(Direction.NORTH, Terrain.STREET);
        neighbors.put(Direction.EAST, Terrain.LIGHT);
        neighbors.put(Direction.WEST, Terrain.CROSSWALK);
        neighbors.put(Direction.SOUTH, Terrain.GRASS);

        final Truck truck = new Truck(0, 0, Direction.NORTH);

        boolean seenNorth = false;
        boolean seenEast = false;
        boolean seenWest = false;

        for (int i = 0; i < TRIES_FOR_RANDOMNESS; i++) {
            final Direction chosenDirection = truck.chooseDirection(neighbors);
            if (chosenDirection == Direction.NORTH) seenNorth = true;
            else if (chosenDirection == Direction.EAST) seenEast = true;
            else if (chosenDirection == Direction.WEST) seenWest = true;
            else fail("Truck should not choose an invalid direction like SOUTH!");
        }

        assertTrue(seenNorth && seenEast && seenWest,
                "Truck should randomly choose among valid directions NORTH, EAST, and WEST.");
    }

    /**
     * Test method for {@link Truck#chooseDirection(java.util.Map)}.
     */
    @Test
    public void testChooseDirectionMustReverse() {

        // NORTH, EAST, and WEST are set to GRASS (impassable), and only SOUTH is STREET (passable).
        // Facing NORTH, the Truck should reverse to SOUTH as the only valid choice.

        final Map<Direction, Terrain> neighbors = new HashMap<>();
        neighbors.put(Direction.NORTH, Terrain.GRASS);
        neighbors.put(Direction.EAST, Terrain.GRASS);
        neighbors.put(Direction.WEST, Terrain.GRASS);
        neighbors.put(Direction.SOUTH, Terrain.STREET); // Only reverse direction is valid

        final Truck truck = new Truck(0, 0, Direction.NORTH);

        // Verify Truck chooses SOUTH when no other options are valid.
        assertEquals(Direction.SOUTH, truck.chooseDirection(neighbors),
                "Truck should reverse direction to SOUTH when it's the only valid choice.");
    }

    /**
     * Test method for {@link Truck#chooseDirection(java.util.Map)}.
     */
    @Test
    public void testChooseDirectionWithMixedTerrains() {
        final Truck truck = new Truck(0, 0, Direction.NORTH);

        // Set up the surrounding terrain: NORTH is STREET, EAST is LIGHT, SOUTH is CROSSWALK,
        // and WEST is GRASS (impassable for Truck). Truck should choose NORTH, EAST, or SOUTH.
        final Map<Direction, Terrain> neighbors = new HashMap<>();
        neighbors.put(Direction.NORTH, Terrain.STREET);
        neighbors.put(Direction.EAST, Terrain.LIGHT);
        neighbors.put(Direction.SOUTH, Terrain.CROSSWALK);
        neighbors.put(Direction.WEST, Terrain.GRASS);

        boolean choseNorth = false;
        boolean choseEast = false;
        boolean choseSouth = false;

        // Run multiple times to account for random direction choice and track chosen directions
        for (int i = 0; i < TRIES_FOR_RANDOMNESS; i++) {
            Direction chosenDirection = truck.chooseDirection(neighbors);
            if (chosenDirection == Direction.NORTH) choseNorth = true;
            else if (chosenDirection == Direction.EAST) choseEast = true;
            else if (chosenDirection == Direction.SOUTH) choseSouth = true;
            else fail("Truck should not choose an invalid direction like WEST!");
        }

        // Ensure the Truck only chooses valid directions (NORTH, EAST, or SOUTH).
        assertTrue(choseNorth || choseEast || choseSouth,
                "Truck should choose NORTH, EAST, or SOUTH direction when those are valid terrains.");
    }
}
