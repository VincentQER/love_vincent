package model;

import java.util.Locale;
import java.util.Random;

/**
 * AbstractVehicle is an abstract class that provides the base structure and common
 * functionality for different types of vehicles in the simulation.
 *
 * @author Vincent Xu
 */
public abstract class AbstractVehicle implements Vehicle {

    /** The initial X-coordinate of the vehicle. */
    private final int myInitialX;

    /** The initial Y-coordinate of the vehicle. */
    private final int myInitialY;

    /** The initial direction of the vehicle. */
    private final Direction myInitialDirection;

    /** The number of moves the vehicle remains dead after a collision. */
    private final int myDeadTime;

    /** The current alive status of the vehicle. */
    private boolean myAlive;

    /** The current X-coordinate of the vehicle. */
    private int myCurrentlyX;

    /** The current Y-coordinate of the vehicle. */
    private int myCurrentlyY;

    /** The number of moves since the vehicle was last poked while dead. */
    private int myPokeCount;

    /** The current direction of the vehicle. */
    private Direction myDirection;

    /** Random generator for selecting random directions. */
    protected final Random myRandom = new Random();

    /**
     * Constructs an AbstractVehicle with the specified initial position, direction, and death time.
     *
     * @param theVehicleX the initial X-coordinate of the vehicle
     * @param theVehicleY the initial Y-coordinate of the vehicle
     * @param direction the initial direction of the vehicle
     * @param theDeadTime the number of moves the vehicle remains dead after a collision
     */
    public AbstractVehicle(final int theVehicleX, final int theVehicleY, final Direction direction, final int theDeadTime) {
        myInitialX = theVehicleX;
        myInitialY = theVehicleY;
        myInitialDirection = direction;
        myDeadTime = theDeadTime;
        reset();
    }

    /**
     * Handles collision behavior for the vehicle. A vehicle dies if it collides
     * with another living vehicle with a shorter death time.
     *
     * @param theOther the other vehicle involved in the collision
     */
    @Override
    public void collide(final Vehicle theOther) {
        if (isAlive() && theOther.isAlive() && (getDeathTime() > theOther.getDeathTime())) {
            myAlive = false;
        }
    }

    /**
     * Gets the death time of the vehicle.
     *
     * @return the death time in moves
     */
    @Override
    public int getDeathTime() {
        return myDeadTime;
    }

    /**
     * Gets the image file name for the vehicle based on its state.
     *
     * @return the file name as a String; appends "_dead" if the vehicle is dead
     */
    @Override
    public String getImageFileName() {
        final StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName().toLowerCase(Locale.US));
        if (!isAlive()) {
            sb.append("_dead.gif");
            return sb.toString();
        }
        sb.append(".gif");
        return sb.toString();
    }

    /**
     * Gets the current direction of the vehicle.
     *
     * @return the current direction of the vehicle
     */
    @Override
    public Direction getDirection() {
        return myDirection;
    }

    /**
     * Gets the current X-coordinate of the vehicle.
     *
     * @return the current X-coordinate
     */
    @Override
    public int getX() {
        return myCurrentlyX;
    }

    /**
     * Gets the current Y-coordinate of the vehicle.
     *
     * @return the current Y-coordinate
     */
    @Override
    public int getY() {
        return myCurrentlyY;
    }

    /**
     * Checks if the vehicle is alive.
     *
     * @return true if the vehicle is alive, false otherwise
     */
    @Override
    public boolean isAlive() {
        return myAlive;
    }

    /**
     * Handles the "poke" behavior. If the vehicle is dead, it increments the poke count.
     * If the poke count reaches the death time, the vehicle revives, resets the poke count,
     * and assigns a random direction.
     */
    @Override
    public void poke() {
        if (!isAlive()) {
            myPokeCount++;
            if (myPokeCount >= myDeadTime) {
                myAlive = true;
                myPokeCount = 0;
                myDirection = Direction.random();
            }
        }
    }

    /**
     * Resets the vehicle to its initial state.
     */
    @Override
    public final void reset() {
        myCurrentlyX = myInitialX;
        myCurrentlyY = myInitialY;
        myDirection = myInitialDirection;
        myAlive = true;
        myPokeCount = 0;
    }

    /**
     * Sets the vehicle's direction to the specified direction.
     *
     * @param theDir the direction to set
     */
    @Override
    public void setDirection(final Direction theDir) {
        myDirection = theDir;
    }

    /**
     * Sets the vehicle's current X-coordinate.
     *
     * @param theX the new X-coordinate
     */
    @Override
    public void setX(final int theX) {
        myCurrentlyX = theX;
    }

    /**
     * Sets the vehicle's current Y-coordinate.
     *
     * @param theY the new Y-coordinate
     */
    @Override
    public void setY(final int theY) {
        myCurrentlyY = theY;
    }
}

