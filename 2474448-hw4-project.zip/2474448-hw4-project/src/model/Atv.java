package model;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * The Atv class represents an All-Terrain Vehicle (ATV) with specific movement and collision behavior.
 *
 * @author Vincent Xu
 */
public class Atv extends AbstractVehicle {

    /** The death time for the ATV after a collision, set to 25 moves. */
    private static final int DEATH_TIME = 25;

    /**
     * Constructs an ATV with the specified initial position and direction.
     *
     * @param theX the initial X-coordinate of the ATV
     * @param theY the initial Y-coordinate of the ATV
     * @param theDir the initial direction of the ATV
     */
    public Atv(final int theX,final int theY, final Direction theDir) {
        super(theX, theY, theDir, DEATH_TIME);
    }

    /**
     * Determines if the ATV can pass a given terrain and light condition
     *
     * @param theTerrain the type of terrain in front of the ATV
     * @param theLight the light condition (red, yellow, or green)
     * @return true if the ATV can pass, false if it encounters a wall
     */
    @Override
    public boolean canPass(final Terrain theTerrain, final Light theLight) {
        return theTerrain != Terrain.WALL; // ATVs can travel on any terrain except walls
    }

    /**
     * Chooses the next direction for the ATV.
     *
     * @param theNeighbors a map of directions to terrain types around the ATV
     * @return the chosen direction
     */
    @Override
    public Direction chooseDirection(final Map<Direction, Terrain> theNeighbors) {
        // Create a list of possible directions (straight, left, right)
        final List<Direction> possibleDirections = new ArrayList<>();
        final Direction currentDirection = getDirection();

        // Add straight, left, and right directions if they are not walls
        if (theNeighbors.get(currentDirection) != Terrain.WALL) {
            possibleDirections.add(currentDirection);
        }
        if (theNeighbors.get(currentDirection.left()) != Terrain.WALL) {
            possibleDirections.add(currentDirection.left());
        }
        if (theNeighbors.get(currentDirection.right()) != Terrain.WALL) {
            possibleDirections.add(currentDirection.right());
        }

        // Randomly select one of the possible directions
        if (!possibleDirections.isEmpty()) {
            return possibleDirections.get(myRandom.nextInt(possibleDirections.size()));
        }

        // Default to straight if no other options are available
        return currentDirection;
    }

}

