package model;

import java.util.Map;

/**
 * A class representing a Taxi vehicle that can navigate through various terrains
 * and respond to traffic lights.
 *
 @author Vincent Xu
 */
public class Taxi extends AbstractVehicle {

    /** Death time after a collision */
    private static final int DEATH_TIME = 15;

    /** Counter to track the number of clock cycles waited at a red crosswalk light. */
    private int myRedCrosswalkWait;

    /** The maximum number of cycles the Taxi waits
     * at a red crosswalk before proceeding.
     * */
    private static final int MAX_WAIT_TIME = 3;

    /** The initial value for the crosswalk wait counter. */
    private static final int INITIAL_WAIT_TIME = 0;

    /**
     * Initializes a Taxi with position and direction.
     *
     * @param theX the initial X-coordinate
     * @param theY the initial Y-coordinate
     * @param theDir the initial direction
     */
    public Taxi(final int theX,final int theY,final Direction theDir) {
        super(theX, theY, theDir, DEATH_TIME);
        myRedCrosswalkWait = 0;
    }

    /**
     * Determines if the taxi can pass based on terrain and light.
     *
     * @param theTerrain the type of terrain
     * @param theLight the traffic light state
     * @return true if passable, false otherwise
     */
    @Override
    public boolean canPass(final Terrain theTerrain, final Light theLight) {
        // Taxis stop at red lights
        if (theTerrain == Terrain.LIGHT && theLight == Light.RED) {
            return false;
        }

        // Taxis stop at red crosswalk lights and wait for 3 cycles or until green
        if (theTerrain == Terrain.CROSSWALK) {
            if (theLight == Light.RED) {
                if (myRedCrosswalkWait < MAX_WAIT_TIME) {
                    myRedCrosswalkWait++;
                    return false; // Stop for the red light at crosswalk
                } else {
                    // Reset the wait counter after 3 cycles
                    myRedCrosswalkWait = INITIAL_WAIT_TIME;
                    return true;
                }
            } else {
                // Reset the wait counter if light is yellow or green
                myRedCrosswalkWait = INITIAL_WAIT_TIME;
            }
        }

        // Taxis can pass on streets or crosswalks with green or yellow lights
        return theTerrain == Terrain.STREET
                || theTerrain == Terrain.LIGHT
                || theTerrain == Terrain.CROSSWALK;
    }

    /**
     * Chooses the next movement direction for the taxi.
     *
     * @param theNeighbors surrounding terrain
     * @return the chosen direction
     */
    @Override
    public Direction chooseDirection(final Map<Direction, Terrain> theNeighbors) {
        final Direction currentDirection = getDirection();

        // Check if we can go straight
        if (isValidTerrain(theNeighbors.get(currentDirection))) {
            return currentDirection;
        }
        // Check if we can turn left
        if (isValidTerrain(theNeighbors.get(currentDirection.left()))) {
            return currentDirection.left();
        }
        // Check if we can turn right
        if (isValidTerrain(theNeighbors.get(currentDirection.right()))) {
            return currentDirection.right();
        }

        // If no other option, reverse
        return currentDirection.reverse();
    }

    /**
     * Helper method
     *
     * @param terrain the terrain to check
     * @return true if passable terrain
     */
    private boolean isValidTerrain(final Terrain terrain) {
        return terrain == Terrain.STREET || terrain == Terrain.LIGHT || terrain == Terrain.CROSSWALK;
    }

}
