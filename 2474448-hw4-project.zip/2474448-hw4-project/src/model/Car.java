package model;

import java.util.Map;

/**
 * A class representing a car vehicle that in the simulation with specific rules
 * for movement and collision behavior.
 *
 * @author Vincent Xu
 */
public class Car extends AbstractVehicle {

    /** The death time for the car after a collision, set to 15 moves. */
    private static final int DEATH_TIME = 15;

    /**
     * Constructs a Car with the specified initial position and direction.
     *
     * @param theX the initial X-coordinate of the Car
     * @param theY the initial Y-coordinate of the Car
     * @param theDir the initial direction of the Car
     */
    public Car(final int theX,final int theY,final Direction theDir) {
        super(theX, theY, theDir, DEATH_TIME);
    }

    /**
     * Determines if the car can pass a given terrain and light condition.
     *
     * @param theTerrain the type of terrain in front of the car
     * @param theLight the light condition (red, yellow, or green)
     * @return true if the car can pass, false otherwise
     */
    @Override
    public boolean canPass(final Terrain theTerrain,final Light theLight) {
        return (theTerrain == Terrain.STREET || (theTerrain == Terrain.LIGHT && theLight != Light.RED))
                || (theTerrain == Terrain.CROSSWALK && theLight == Light.GREEN);
    }

    /**
     * Chooses the next direction for the car.
     * Prefer to move straight, then left, then right. If none are valid, reverse.
     *
     * @param theNeighbors a map of directions to terrain types around the car
     * @return the chosen direction
     */
    @Override
    public Direction chooseDirection(final Map<Direction, Terrain> theNeighbors) {
        final Direction currentDirection = getDirection();

        // Prioritize checking directions: straight, left, and right
        if (isValidTerrain(theNeighbors.get(currentDirection))) {
            return currentDirection;
        }
        if (isValidTerrain(theNeighbors.get(currentDirection.left()))) {
            return currentDirection.left();
        }
        if (isValidTerrain(theNeighbors.get(currentDirection.right()))) {
            return currentDirection.right();
        }

        // If no other option, reverse
        return currentDirection.reverse();
    }

    /**
     * Helper method
     *
     * @param terrain the terrain to check
     * @return true if the terrain is STREET, LIGHT, or CROSSWALK
     */
    private boolean isValidTerrain(final Terrain terrain) {
        return terrain == Terrain.STREET || terrain == Terrain.LIGHT || terrain == Terrain.CROSSWALK;
    }

}
