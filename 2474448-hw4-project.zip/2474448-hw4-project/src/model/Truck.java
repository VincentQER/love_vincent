package model;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * A class representing a Trucks vehicle that can only travel on
 * streets, lights, and crosswalks, and they behave differently
 * based on terrain and light conditions.
 *
 * @author Vincent Xu
 */
public class Truck extends AbstractVehicle {

    /** The death time for the truck, always zero as trucks do not die. */
    private static final int DEATH_TIME = 0;

    /**
     * Constructs a Truck with the initial position and direction.
     *
     * @param vehicleX the initial X-coordinate of the Truck
     * @param vehicleY the initial Y-coordinate of the Truck
     * @param direction the initial direction of the Truck
     */
    public Truck(final int vehicleX, final int vehicleY, final Direction direction) {
        super(vehicleX, vehicleY, direction, DEATH_TIME);
    }

    /**
     * Determines if the truck can pass over a given terrain and light condition.
     *
     * @param theTerrain the type of terrain in front of the truck
     * @param theLight the light condition
     * @return result of Terrain condition.
     */
    @Override
    public boolean canPass(final Terrain theTerrain, final Light theLight) {
        return theTerrain == Terrain.STREET
                || theTerrain == Terrain.LIGHT
                || (theTerrain == Terrain.CROSSWALK && theLight != Light.RED);
    }

    /**
     * Chooses the next direction for the truck. The truck tries to move straight,
     * left, or right on valid terrains (STREET, LIGHT, or CROSSWALK). If none of
     * these directions is available, it reverses direction.
     *
     * @param theNeighbors a map of directions to terrain types around the truck
     * @return the chosen direction
     */
    @Override
    public Direction chooseDirection(final Map<Direction, Terrain> theNeighbors) {
        final List<Direction> possibleDirections = new ArrayList<>();

        // Add valid directions if they are street, light, or crosswalk
        if (isValidTerrain(theNeighbors.get(getDirection()))) {
            possibleDirections.add(getDirection());
        }
        if (isValidTerrain(theNeighbors.get(getDirection().left()))) {
            possibleDirections.add(getDirection().left());
        }
        if (isValidTerrain(theNeighbors.get(getDirection().right()))) {
            possibleDirections.add(getDirection().right());
        }

        return possibleDirections.isEmpty() ?
                getDirection().reverse() :
                possibleDirections.get(myRandom.nextInt(possibleDirections.size()));

    }

    /**
     * Helper method
     *
     * @param terrain the terrain to check
     * @return true if the terrain is street, light, or crosswalk
     */
    private boolean isValidTerrain(final Terrain terrain) {
        return terrain == Terrain.STREET
                || terrain == Terrain.LIGHT
                || terrain == Terrain.CROSSWALK;
    }

}

