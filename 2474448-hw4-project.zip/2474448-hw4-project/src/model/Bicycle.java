package model;

import java.util.Map;

/**
 * The Bicycle class represents a bicycle vehicle in the simulation
 * with specific movement and collision behavior.
 *
 * @author Vincent Xu
 */
public class Bicycle extends AbstractVehicle {

    /** The death time for the bicycle after a collision, set to 35 moves. */
    private static final int DEATH_TIME = 35;

    /**
     * Constructs a Bicycle with the specified initial position and direction.
     *
     * @param theX the initial X-coordinate of the bicycle
     * @param theY the initial Y-coordinate of the bicycle
     * @param theDir the initial direction of the bicycle
     */
    public Bicycle(final int theX,final int theY,final Direction theDir) {
        super(theX, theY, theDir, DEATH_TIME);
    }

    /**
     * Determines if the bicycle can pass a given terrain and light condition.
     *
     * @param theTerrain the type of terrain in front of the bicycle
     * @param theLight the light condition
     * @return true if the bicycle can pass, false otherwise
     */
    @Override
    public boolean canPass(final Terrain theTerrain,final Light theLight) {
        // Bicycles can always pass trails
        if (theTerrain == Terrain.TRAIL) {
            return true;
        }
        // Bicycles only stop for yellow and red lights
        if ((theTerrain == Terrain.LIGHT || theTerrain == Terrain.CROSSWALK)
                && (theLight == Light.RED || theLight == Light.YELLOW)) {
            return false;
        }
        // Can pass on streets, lights, and crosswalks otherwise
        return theTerrain == Terrain.STREET || theTerrain == Terrain.LIGHT || theTerrain == Terrain.CROSSWALK;

    }

    /**
     * Chooses the next direction for the bicycle.
     *
     * @param theNeighbors a map of directions to terrain
     * @return the chosen direction
     */
    @Override
    public Direction chooseDirection(final Map<Direction, Terrain> theNeighbors) {
        final Direction currentDirection = getDirection();

        // Prefer to move straight on a trail
        if (theNeighbors.get(currentDirection) == Terrain.TRAIL) {
            return currentDirection;
        }

        // Check if a trail is to the left or right
        if (theNeighbors.get(currentDirection.left()) == Terrain.TRAIL) {
            return currentDirection.left();
        }
        if (theNeighbors.get(currentDirection.right()) == Terrain.TRAIL) {
            return currentDirection.right();
        }

        // Prefer moving straight on street, light, or crosswalk
        if (isValidTerrain(theNeighbors.get(currentDirection))) {
            return currentDirection;
        }

        // If straight isn't an option, try left then right
        if (isValidTerrain(theNeighbors.get(currentDirection.left()))) {
            return currentDirection.left();
        }
        if (isValidTerrain(theNeighbors.get(currentDirection.right()))) {
            return currentDirection.right();
        }

        // As a last resort, reverse
        return currentDirection.reverse();
    }

    /**
     * Helper method
     *
     * @param terrain the terrain to check
     * @return true if the terrain is street, light, or crosswalk
     */
    private boolean isValidTerrain(final Terrain terrain) {
        return terrain == Terrain.STREET || terrain == Terrain.LIGHT || terrain == Terrain.CROSSWALK;
    }

}
