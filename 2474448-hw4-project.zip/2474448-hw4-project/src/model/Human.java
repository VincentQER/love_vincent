package model;

import java.util.*;

/**
 * The Human class represents a human character in the simulation with specific movement and
 * collision behavior.
 *
 * @author Vincent Xu
 */
public class Human extends AbstractVehicle {

    /** The death time for the human after a collision, set to 45 moves. */
    private static final int DEATH_TIME = 45;

    /**
     * Constructs a Human with the specified initial position and direction.
     *
     * @param theX the initial X-coordinate of the human
     * @param theY the initial Y-coordinate of the human
     * @param theDir the initial direction of the human
     */
    public Human(final int theX, final int theY, final Direction theDir) {
        super(theX, theY, theDir, DEATH_TIME);
    }

    /**
     * Determines if the human can pass a given terrain and light condition.
     *
     * Humans can only travel on grass and crosswalks.
     * Never cross crosswalks when the light is green.
     * Only cross crosswalks when the light is yellow or red.
     *
     * @param theTerrain the type of terrain
     * @param theLight the light condition
     * @return true if the human can pass, false otherwise
     */
    @Override
    public boolean canPass(final Terrain theTerrain, final Light theLight) {
        return theTerrain == Terrain.GRASS || theTerrain == Terrain.CROSSWALK &&
                (theLight== Light.YELLOW || theLight == Light.RED);
    }

    /**
     * Chooses the next direction for the human.
     * Humans move randomly on grass or crosswalks and prefer crosswalks if adjacent.
     *
     * @param theNeighbors a map of directions to terrain types around the human
     * @return the chosen direction
     */
    @Override
    public Direction chooseDirection(final Map<Direction, Terrain> theNeighbors) {
        final List<Direction> directions = new ArrayList<>();

        // Check if the forward, left, and right directions have valid terrain
        if (isValidTerrain(theNeighbors.get(getDirection()))) {
            directions.add(getDirection());
        }
        if (isValidTerrain(theNeighbors.get(getDirection().left()))) {
            directions.add(getDirection().left());
        }
        if (isValidTerrain(theNeighbors.get(getDirection().right()))) {
            directions.add(getDirection().right());
        }

        // Prioritize moving towards CROSSWALK if one is in a valid direction.
        for (final Direction direction : directions) {
            if (theNeighbors.get(direction) == Terrain.CROSSWALK) {
                return direction;
            }
        }

        // Reverse direction if no direction ar available
        if (directions.isEmpty()) {
            return getDirection().reverse();
        }

        // Select a random direction
        Collections.shuffle(directions);
        return directions.get(0);
    }

    /**
     * Checks if the given terrain is a valid terrain.
     *
     * @param theTerrain the terrain type to check
     * @return true if the terrain is GRASS or CROSSWALK, false otherwise
     */
    public boolean isValidTerrain(final Terrain theTerrain) {
        return theTerrain == Terrain.GRASS || theTerrain == Terrain.CROSSWALK;
    }

}

